import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup} from '@angular/forms';
import {Validators} from '@angular/forms';
import {FormBuilder,FormArray } from '@angular/forms';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  contactForm: FormGroup : new FormGroup({});
  constructor(private fb:FormBuilder) {}

  ngOnInit() 
  {
      this.contactForm = this.fb.group({
      name: new FormControl(),
      password: new FormControl(),
      age: new FormControl(),
      gender: new FormControl(),
      city: new FormControl(),
      formdetails:this.fb.array([this.createformdetails()])
    });
  }

  createformdetails()
  {
    return this.fb.group
    (
        {
          product:new FormControl(),
          amount:new FormControl()
        }
    )
  }

  addetails()
  {
    const details = this.contactForm.controls.formdetails as FormArray();
    details.push(this.createformdetails());
    console.log(this.contactForm.value);
  }
  removedetails(index)
  {
    console.log(index);
    const details = this.contactForm.controls.formDetails as FormArray();
    details.removeAt(index);
  }
  submit()
  {
    console.log(this.contactForm.value);
  }
}
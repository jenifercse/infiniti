<div>

	<?php
		if ( isset($_GET['err']) )
		{
			if ( $_GET['err'] == 1  ) 
			{
				echo "<b> <span style='color:red'>* Incorrect Username or Password * </span> </b>";
				
			}
			elseif ( $_GET['err'] == 0 ) 
			{
				echo "<b> <span style='color:red'>* Your account need to be activated * </span></b>";
			}
			else
			{
				header("Location:" . BASE_URL );
			}
		}
		else{
			echo "<b> <span style='color:red'>* Incorrect Username or Password * </span></b>";
		}
	?>
	
</div>
<!-- <script type="text/javascript" src="public/js/jquery.min.js"></script> -->
<script language="javascript">
	// alert("hola");
$(document).ready(function(){
	$('#signup').click(function(){

		// alert("hola");
		// alert(2);
		$('#newuser').action="index.php?admin/signupnew";
		$('#newuser').submit();
			
			$('#newuser').action="index.php?";
			$('#newuser').submit();
			
	});
});
</script>
<div class="container-fluid">
	<!-- ------------------- -->
	<head>
	<title>Login </title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="public/css/util.css">
	<link rel="stylesheet" type="text/css" href="public/css/main.css">

</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50">
				<form class="login100-form validate-form" id="newuser" name="newuser">
					<span class="login100-form-title p-b-33">
						LOGIN
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="user_name" placeholder="USERNAME" id="user_name">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="wrap-input100 rs1 validate-input" data-validate="Password is required">
						<input class="input100" type="password" id="user_password" name="user_password"  placeholder="PASSWORD">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="container-login100-form-btn m-t-20">
						<input type="submit" value="Login" id="signup" class="login100-form-btn">
							 
						<!-- </button> -->
					</div>

					<div class="text-center p-t-45 p-b-4">
						<span class="txt1">
							Forgot
						</span>

						<a href="#" class="txt2 hov1">
							Username / Password?
						</a>
					</div>

					<div class="text-center">
						<span class="txt1">
							Create an account?
						</span>

						<a href="index.php?admin/signupnew" class="txt2 hov1">
							Sign up
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	
	<!-- ------------------------------- -->
</div>







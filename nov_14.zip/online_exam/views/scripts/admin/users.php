<div>
	<div id="users" class="users">
		<div>
			<!--
			<input type="button" style="width: 150px; height: 25px;" value="Add New" id="add">
			-->
		<a href="javascript:loadPage('index.php?admin/usersadd');">Add new</a>
	    </div><br />
	<div id="user_list" class="user_list">

	</div>
	</div>
</div>


<script language="javascript">
$(document).ready(function(){
	$.get('index.php?admin/userslist',function(data){
		$('#user_list').html(data);
	})
	/*
	$('#add').click(function(){
		$('#users').load('index.php?admin/usersadd');
	});
	*/
});
</script>

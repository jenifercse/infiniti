


<div  id="departments" class="users">
	<div>
		<a href="javascript:loadPage('index.php?admin/departmentsadd');">Add new </a>
		<!--
		<input type="button" style="width: 150px; height: 25px;" value="Add New" id="add">
	-->
	</div><br/>
	<div id="dept_list" class="dept_list">

	</div>
</div>



<script language="javascript">
$(document).ready(function(){
	
	$.get('index.php?admin/departmentlist',function(data){
		$('#dept_list').html(data);
	})
	/*
	$('#add').click(function(){
		$('#departments').load('index.php?admin/departmentsadd');
	});
	*/
});
</script>
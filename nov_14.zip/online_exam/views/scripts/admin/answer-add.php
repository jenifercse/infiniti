
<div>
	<form>
		<fieldset>
		<legend>ADD ANSWER</legend>
		<div class="form-group">
			<label for="answer" class>Answer</label><br>
			
				<input type="text" id="answer_name" class="user_input"/> 
				<input type="checkbox" id="right_answer"/> Correct Answer
			</div>

			<input type='button' class="btn btn-info" id="save" name="save" value="Save"/>
			<a href="#" id="cancel" name="cancel" value="Cancel">cancel</a>

		<input type="hidden" id="question_id" value="<?php echo $data['question_id'];?>">
		<input type="hidden" id="exam_id" value="<?php echo $data['exam_id'];?>">
		</fieldset>

	</form>
</div>




<script language="javascript">
$(document).ready(function(){
	$('#cancel').click(function(){
		loadPage('index.php?admin/questionlist&exam_id='+ $('#exam_id').val());
	});
	$('#save').click(function(){
		var flag = 0;
		if ($('#right_answer').attr('checked')){
			flag = 1;
		}

		$.post('index.php?admin/answeraddinsert',{'answer_name': $('#answer_name').val(), 'flag':flag, 'question_id' : $('#question_id').val()}, function(){
			loadPage('index.php?admin/questionlist&exam_id='+ $('#exam_id').val());
		});
		
	
	});
});
</script>
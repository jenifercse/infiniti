
	<div  id="questions" class="questions">
	<div id="question_dtl" class="question_dtl" style="">
	<table>
	<tr>
		<td>
			Question : 
		</td>
		<td>
			<textarea id="question_name" name="question_name" rows="6" cols="38"> </textarea>
		</td>
	</tr>
	<tr>
		<td> 
			Question type : 
		</td>
		<td>
		<select id="question_type" name="question_type"> 
			<option value="0"> Multiple Choice</option>
			<option value="1"> Essay </option>
		</select>
		</td>
	</tr>
	<tr>
		<table id="points">
		</tr>
			<td> 
				Essay Points : 
			</td>
			<td> 
				<input type="text" id="essay_points" onKeyPress="return isNumberKey(event);"/> 
			</td>
		</tr>
		</table>
	</tr>
	<tr>
		<td></td>
		<td>
			<input type="button" id="save" name="save" value="Save"/>
			<input type="button" id="cancel" name="cancel" value="Cancel"/>
		</td>
	</tr>
	</table>
	</div>

<input type="hidden" id="exam_id" name="exam_id" value="<?php echo $data; ?>"/>
</div>




<script language="javascript">
var answer = 1;
$(document).ready(function(){
	$('#cancel').click(function(){
		loadPage('index.php?admin/questionlist&exam_id='+$('#exam_id').val());
	});
	$('#save').click(function(){
		var essay_points = 0;
		if ( $('#essay_points').val() != '' ) {
			essay_points = $('#essay_points').val();
		}
		$.post('index.php?admin/questionaddinsert',{
			'question_name' : $('#question_name').val(), 
				'question_type' :  $('#question_type :selected').val(), 'exam_id':$('#exam_id').val(), 'essay_points' : essay_points
			},function(){
				loadPage('index.php?admin/questionlist&exam_id='+$('#exam_id').val());
			});
	});
	$('#question_type').change(function(){
		if ( $(this).val() == 0 ){
			$('#points').css('display','none');
		}else{
			$('#points').css('display','block');
		}
	});
	
});
function isNumberKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
} 
</script>
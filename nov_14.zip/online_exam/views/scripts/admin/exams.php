
<div>
<div id="exam" class="users" >
		<table class="table table-striped table-bordered">
		<tr>
			<td>
				<button class="btn btn-basic">
				<a href="javascript:loadPage('index.php?admin/examsadd');">Add new
				</a>
				</button>
			</td>
		
			<td width="330"> &nbsp;</td>

			<td> 
				Exam From 
				<input maxlength="10" id="range_from" name="range_from" class="user_input" type="text" value="2013-04-03">
				&nbsp;&nbsp;&nbsp;
				 Exam To 
				<input maxlength="10" id="range_to" name="range_to" class="user_input" type="text">
			</td>
		</tr>
		</table>
	</div>
	<br>
	<div id="exam_list" class="exam_list" >
	</div>
</div>
</div>



<script language="javascript">
$(document).ready(function(){
	$("#range_from").datepicker({dateFormat: 'yy-mm-dd'});
	$("#range_to").datepicker({dateFormat: 'yy-mm-dd'});
	$('#range_from').change(function(){
		//alert($(this).val());
		if ( $('#range_to').val().length > 1 ) {
			$.post('index.php?admin/examslist',{ 'from' : $('#range_from').val(), 'to' : $('#range_to').val() },
			function( data ){
				$('#exam_list').html( data );
			})
		}
	});
	$('#range_to').change(function(){
		if ( $('#range_from').val().length > 1 ) {
			$.post('index.php?admin/examslist',{ 'from' : $('#range_from').val(), 'to' : $('#range_to').val() },
			function( data ){
				$('#exam_list').html( data );
			})
		}
	});
	$.get('index.php?admin/examslist',function(data){
		$('#exam_list').html(data);
	})

	$('#add').click(function(){
		$('#exam').load('index.php?admin/examsadd');
	});
});
</script>

	<div class="row">
		
	<div id="users"  class="users" >
	<div class="user_add_data">
		<form  class="form-inline add-user" name="user_add" id="user_add" action="index.php?admin/saveusernew">
			<fieldset><legend class="text-center">ADD USER</legend>
				<div class="row">
					<div class="col-md-4">
						<label for="first_name" class="form-group">First name</label><br>
						<input type="text" id="fname" name="fname" class="user_input"> 
					</div>
					<div class="col-md-4">
						<label for="last-name" class="form-group">Last name</label><br>
						<input type="text" id="lname" name="lname" class="user_input">
					</div><br>
					<div class="col-md-4"></div>
				</div>
				<div class="row">
				<div class="col-md-4">
					<label for="user-name" class="form-group">username</label> 
					<input type="text" id="user_name" name="user_name" class="user_input"> 
				</div>
				<div class="col-md-4">
					<label for="password" class="form-group">password</label>
					<input type="password" id="password" name="password" class="user_input"> 
				</div>
				<div class="col-md-4"></div>
				</div><br>
				<div class="row">
				<div class="col-md-4">
					<label for="role" class="form-group">Role</label><br>
						<select id="role_id" name="role_id">
						<?php 
						if (is_array($data['role'])){
							foreach($data['role'] as $row){
						?>
						<option value="<?php echo $row['role_id']; ?>"> <?php echo $row['role_name']; ?></option>
						<?php
							}
						}
						?>
						</select>
				</div>
			
				<div class="col-md-4">
					 <label for="department" class="form-group">Department Name</label>
					
						<select id="dept_id" name="dept_id">
							<?php
							if (is_array($data['department'])){
								foreach($data['department'] as $row){
							?>
							<option value="<?php echo $row['department_id']; ?>"> <?php echo $row['department_name'];?> </option>
							<?php
									}
								}
							?>
						</select>
				</div>
				<div class="col-md-4"></div><br>
				</div><br>
				<div>
					<input type="checkbox" id="u_examchecker" name="u_examchecker">
					<label for="exam-checker" class="form-group">Exam Checker</label> 
				</div><br>
				<div>
					 <input type="checkbox" id="u_enable" name="u_enable"> 
					 <label for="enable" class="form-group">Enable</label>
				</div><br>
				<div>
					<input type="button" id="save" class="btn btn-info" value="Save">
					<a href="#" id="cancel"  value="Cancel">cancel</a>
				</div><br>
			</fieldset>
		</form>
	</div>
</div>
</div>


<script language="javascript">

$(document).ready(function(){
	$('#cancel').click(function(){
		//$('#users').load('index.php?admin/users');
		loadPage('index.php?admin/users');
	})
	$('#save').click(function(){
		var error ="Please fill up the requirement below \r\n----------------------------------------\r\n";
		var msg = error;
		if( $('#fname').val() == '' ){
			msg += '*First name \r\n';
		}
		if( $('#lname').val() == '' ){
			msg += '*Last name \r\n';
		}
		if( $('#user_name').val() == '' ){
			msg += '*user name \r\n';
		}
		if( $('#password').val() == '' ){
			msg += '*Password \r\n';
		}
		if (msg == error){
			
			$.post('index.php?admin/saveusernew',$("#user_add").serialize(),function(data){
				//$('#users').load('index.php?admin/users');
				loadPage('index.php?admin/users');
			});	
			
		}else{
			alert(msg);	
		}
		
		
	});
});
</script>

<div>
 <table width="100%" class="table table-striped table-bordered" >
	<tr>
		<th>  Examinees Name </th>
		<th>Exam Name </th>
		<th>Remarks </th>
		<th>  View </th>
	</tr>

	<?php
		if(is_array($data['exam'])){
			foreach($data['exam'] as $row){
	?>
	<tr>
		<td> <?php echo $row['user_lname'] . ', ' . $row['user_fname'];?></td>
		<td> <?php echo $row['exam_name']; ?></td>
	<?php
	?>
		<td> 
			<?php 
				//print_r($data);
				//echo $data[$row['user_id']][$row['exam_id']][0]['score'];
				if ( (($data[$row['user_id']][$row['exam_id']][0]['score'] / $row['passing_score']) * 100 ) >= $row['passing_grade'] ) {
					echo "<span style='color: green;'><b>Passed</b></span>";
				}else{
					echo "<span style='color: red;'><b>Failed</b></span>";
				}
			?> 
		</td>
		<td> <a href="javascript:loadPage('index.php?admin/checkresult&exam_id=<?php echo $row['exam_id'];?>' + '&user_id=<?php echo $row['user_id'];?>');"> Check Results</a></td>

	</tr>
	<?php
			}
		}
	?>

</table>
</div>


 
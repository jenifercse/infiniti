
    <div>
    <table width="90%" class="table table-striped table-bordered">
        <tr>
            <th> Firstname </th>
            <th> Lastname </th>
            <th> Username </th>
            <th> Department </th>
            <th> Role </th>
            <th> Date Registered </th>
            <th> Action</th>
        </tr>

        <?php
        if (is_array($data)) {

            foreach ($data as $row) {
                ?>
                <?php
            //      print_r($data);

            // exit();
                if ($row['user_enabled'] == 1) {
                    if ($row['exam_checker'] == 1) {
                        $color = '#ffe1e1';
                    } else {
                        $color = '';
                    }
                } else {
                    $color = '#E5E5E5';
                }
                ?>
                <tr style="background: <?php echo $color; ?>">
                    <td> <?php echo $row['user_fname']; ?> </td>
                    <td> <?php echo $row['user_lname']; ?> </td>
                    <td> <?php echo $row['user_name']; ?> </td>
                    <td> <?php echo $row['department_name']; ?> </td>
                    <td> <?php echo $row['role_name']; ?> </td>
                    <td> <?php echo date('m-d-Y', strtotime($row['user_createdon'])); //$row['user_createdon'];                     ?> </td>
                    <td>
                        <a href="javascript:loadPage('index.php?admin/useredit&user_id=<?php echo $row['user_id']; ?>');"> <i class="fa fa-pencil" aria-hidden="true"></i></a>&nbsp;|
                        <a href="javascript:deleteData('index.php?admin/userdelete&user_id=<?php echo $row['user_id']; ?>','index.php?admin/users');"><i class="fa fa-trash" aria-hidden="true"></i>
                        </a>
                    </td>
                </tr>
                <?php
            }
        }
        ?>
    </table>
</div>


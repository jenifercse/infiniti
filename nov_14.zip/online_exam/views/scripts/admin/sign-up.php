
<link href="public/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">

<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="public/js/jquery.min.js"></script>
<link rel="stylesheet" href="public/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="public/font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="public/bootstrap4/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="public/css/util.css">
<link rel="stylesheet" type="text/css" href="public/css/main.css">

<body>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50">
			
				<form  name="user_add" id="user_add" method="post" action="index.php?" class="login100-form validate-form">
				<span class="login100-form-title p-b-33">
						signup
				</span>

				<div class="form-group input-group" class="wrap-input100 validate-input">
					<div class="input-group-prepend">
					    <span class="input-group-text"> <i class="fa fa-user"></i> </span>
					 </div>
			         <input type="text" id="fname" name="fname" class="form-control" 
			         placeholder="firstname" >
			    </div> <!-- form-group// -->

			    <div class="form-group input-group">
					<div class="input-group-prepend">
					    <span class="input-group-text"> <i class="fa fa-user"></i> </span>
					 </div>
			        
			         <input type="text" id="lname" name="lname" class="form-control" placeholder="lastname" >
			    </div> <!-- form-group// -->
			    
			    <div class="form-group input-group">
			    	<div class="input-group-prepend">
					    <span class="input-group-text"> <i class="fa fa-user-circle"></i> </span>
					 </div>
			       <!--  <input name="" class="form-control" placeholder="user name" type="text"> -->
			        <input type="text" id="user_name" name="user_name" class="form-control" placeholder="user name">
			    </div> <!-- form-group// -->
			    
			    <div class="form-group input-group">
			    	<div class="input-group-prepend">
					    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
					</div>
			        
			        <input type="password" id="password" name="password" placeholder="Create password" class="form-control" >
			    </div> <!-- form-group// -->
			    <div class="form-group input-group">
			    	<div class="input-group-prepend">
					    <span class="input-group-text"> <i class="fa fa-building"></i> </span>
					</div>
					
					<select id="dept_id" name="dept_id" class="form-control">
							<option value=""> </option>
							<?php
							if (is_array($data['department'])){
								foreach($data['department'] as $row){
							?>
							<option value="<?php echo $row['department_id']; ?>"> <?php echo $row['department_name'];?> </option>
							<?php
									}
								}
							?>
						</select>
				</div> <!-- form-group end.// -->
			    
			    <span style="color:red;"><b> * Please choice your designated Department * </b></span>
			                                
			    <p class="text-center"> 
			    	<input type="button" id="save" class="btn btn-info" value="Save"">
			    	<input type="button" id="cancel" class="btn btn-info" value="Cancel"> 
			    </p>                                                                 
			</form>
			
	</div> <!-- card.// -->
</div>
</div> 
<!--container end.//-->
</body>


<script src="public/js/jquery.min.js"></script>
<script language="javascript">

$(document).ready(function(){

	$('#cancel').click(function(){
		//$('#users').load('index.php?');
		$('#user_add').action="index.php?"
		$('#user_add').submit();
	})
	$('#save').click(function(){
		var error ="Please fill up the requirement below \r\n----------------------------------------\r\n";
		var msg = error;
		if( $('#fname').val() == '' ){
			msg += '*First name \r\n';
		}
		if( $('#lname').val() == '' ){
			msg += '*Last name \r\n';
		}
		if( $('#user_name').val() == '' ){
			msg += '*user name \r\n';
		}
		if( $('#password').val() == '' ){
			msg += '*Password \r\n';
		}
		if( $('#dept_id').val() == '' ){
			msg += '*Department name \r\n';
		}
		if (msg == error){
			
			$.post('index.php?admin/signupadd',$("#user_add").serialize(),function(data){
				if ( parseInt(data) == 0 ) {
					alert('Your Registration is Success');
					$('#user_add').submit();
				}else{
					alert('Username is Already Exist');
				}

				//alert(data);
				//$('#user_add').submit();
			});	
			
		}else{
			alert(msg);	
		}
		
		
	});
});
</script>

</html>
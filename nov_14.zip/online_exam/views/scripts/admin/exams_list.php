    
<div>
    <table width="90%" class="table table-striped table-bordered">
        <tr>
            <th><b> Exam Name </b></th>
            <th> <b>Exam Period </b></th>
            <th> <b>Department </b></th>
            <th><b>Action</b></th>
        </tr>
        <?php
        if (is_array($data)) {
            foreach ($data as $row) {
                // index.php?admin/examedit&exam_id=23
                //$link = "javascript:loadPage('index.php?admin/examedit&exam_id=".$row['exam_id']."')";
                $link = "javascript:loadPage('index.php?admin/questionlist&exam_id=" . $row['exam_id'] . "')";
                ?>
                <tr>
                    <td> <?php echo "<a href=$link>" . $row['exam_name'] . "</a>"; ?> </td>
                    <td> <?php echo date('m-d-Y', strtotime($row['exam_from'])) . ' - ' . date('m-d-Y', strtotime($row['exam_to'])); ?> </td>
                    <td> <?php echo $row['department_name'];?></td>
                    <td>
                        <a href="javascript:loadPage('index.php?admin/examedit&exam_id=<?php echo $row['exam_id'] ?>');"> <i class="fa fa-pencil" aria-hidden="true"></i></a>&nbsp;|
                        <a href="javascript:deleteData('index.php?admin/questiondelete&exam_id=<?php echo $row['exam_id'] ?>','index.php?admin/exams');"><i class="fa fa-trash" aria-hidden="true"></i></a>
                    </td>
                </tr>
                <?php
            }
        }
        ?>
    </table>
</div>



<script language="javascript">
    $(document).ready(function(){
        /*
        $('.question').click(function(){
                loadPage('index.php?admin/questions&exam_id='+ $(this).attr('id'));
        });
         */
        $('.edit').click(function(){
            //alert($(this).attr('id'));
            loadPage('index.php?admin/questionlist&exam_id='+ $(this).attr('id'));
        });
    });
</script>

    <div>
    <table class="table table-striped table-bordered">
        <tr>
            <th> Department Name </th>
            <th> Action </th>
        </tr>
        <?php
        if (is_array($data)) {
            foreach ($data as $row) {
                ?>
                <tr>
                    <td> <?php echo $row['department_name']; ?> </td>
                    <td>
                        <a href="javascript:loadPage('index.php?admin/departmentedit&department_id=<?php echo $row['department_id']; ?>');"> <i class="fa fa-pencil" aria-hidden="true"></i></a>&nbsp;|
                        <a href="javascript:deleteData('index.php?admin/departmentdelete&department_id=<?php echo $row['department_id']; ?>','index.php?admin/departments');"> <i class="fa fa-trash" aria-hidden="true"></i></a>
                        <!--
                        <input type="button" id="edit" name="edit" value="Edit" style="width:50px; height: 25px;"/>
                        <input type="button" id="delete" name="delete" value="Delete" style="width: 50px; height: 25px;"/>
                        -->
                    </td>
                </tr>
                <?php
            }
        }
        ?>
    </table>
</div>





<div id="department" class="department">
<div class="dept_add_data">
	<form name="dept_add" id="dept_add" class="form" align=center>
		<fieldset><legend class="text-center">ADD DEPARTMENT</legend>
			<div class="row">
			<div class="col-md-6">
				<label for="dept_code" class="form-group">Department Code </label><br>
				<input type="text" id="department_code" name="department_code" class="user_input"/>
			</div>
			<div class="col-md-6">
				<label for="dept_name" class="form-group">Department Name</label><br>
				<input type="text" id="department_name" name="department_name" class="user_input"/> 
			</div>
			             
			</div><br>
			<div class="row">
				
					<input type="button" id="save" class="btn btn-info" value="Save">
					<a href="#" id="cancel"  value="Cancel">cancel</a>
				
			</div>
		
		</fieldset>
	</form>
	</div>
</div>


<script language="javascript">

$(document).ready(function(){
	$('#cancel').click(function(){
		$('#department').load('index.php?admin/departments');
	})
	$('#save').click(function(){
		var error ="Please fill up the requirement below \r\n----------------------------------------\r\n";
		var msg = error;
		if( $('#department_name').val() == '' ){
			msg += '*Department Name \r\n';
		}
		if (msg == error){
			$.post('index.php?admin/savedepartmentnew',$("#dept_add").serialize(),function(data){
				$('#department').load('index.php?admin/departments');
			});	
			
		}else{
			alert(msg);	
		}
	});
});
</script>
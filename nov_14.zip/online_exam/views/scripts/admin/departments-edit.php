
	<div  id="department" class="department" >
	<div class="dept_add_data">
	<form name="dept_add" id="dept_add" class="form-inline">
	<fieldset>
	<legend>EDIT DEPARTMENT</legend>
	<div class="row">
		 <label for="dept_name" class="form-group">Department Name </label>
		<input type="text" id="department_name" name="department_name" class="user_input" value="<?php echo $data[0]['department_name'];?>"/>
	</div><br>
	<div class="row">
		<input type="button" id="save" class="btn btn-info" value="Save">
		<a href="#" id="cancel" value="Cancel">cancel</a>
	</div>

		<input type="hidden" id="department_id" name="department_id" value="<?php echo $data[0]['department_id'];?>">
	</fieldset>
	</form>
	</div>
</div>




<script language="javascript">

$(document).ready(function(){
	$('#cancel').click(function(){
		$('#department').load('index.php?admin/departments');
	})
	$('#save').click(function(){
		var error ="Please fill up the requirement below \r\n----------------------------------------\r\n";
		var msg = error;
		if( $('#department_name').val() == '' ){
			msg += '*Department Name \r\n';
		}
		if (msg == error){
			$.post('index.php?admin/departmentupdate',$("#dept_add, :hidden").serialize(),function(data){
				$('#department').load('index.php?admin/departments');
			});	
			
		}else{
			alert(msg);	
		}
	});
});
</script>
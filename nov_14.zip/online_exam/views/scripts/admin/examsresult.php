
    <div>
    <table width="100%">
        <tr>
            <td align="right"> 
                Exam From 
                <input id="range_from" name="range_from" class="user_input" type="text" value="2013-04-03">
                &nbsp;&nbsp;&nbsp;
                Exam To 
                <input id="range_to" name="range_to" class="user_input" type="text">
            </td>
        </tr>
    </table>
    <br>
    <br>
    <div id="result">
        <table width="100%" class="table table-striped table-bordered">
            <tr>
                <th>  Examinees Name </th>
                <th> Exam Name </th>
                <th>Scores </th>
                <th>Exam </br>Remarks </th>
                <th>Check </br> Status  </th>
                <th>  View </th>
            </tr>

            <?php
            //print_r($data);
            if (is_array($data['exam'])) {
                foreach ($data['exam'] as $row) {
                    ?>
                    <tr>
                        <td> <?php echo $row['user_lname'] . ', ' . $row['user_fname']; ?></td>
                        <td> <?php echo $row['exam_name']; ?></td>
                        <td> <?php echo ( $data[$row['user_id']][$row['exam_id']][0]['score'] == $row['passing_score'] ) ? 'PERFECT' : $data[$row['user_id']][$row['exam_id']][0]['score'] . ' over '. $row['passing_score']; ?> </td>
                        <td>
                            <?php
                           // echo $data[$row['user_id']][$row['exam_id']][0]['score'];
                            
                            if ((($data[$row['user_id']][$row['exam_id']][0]['score'] / $row['passing_score']) * 100 ) >= $row['passing_grade']) {
                                echo "<span style='color: green;'><b>Passed</b></span>";
                            } else {
                                echo "<span style='color: red;'><b>Failed</b></span>";
                               //echo  ($data[$row['user_id']][0]['score'] / $row['passing_score']) * 100;
                                //echo $data[$row['user_id']][0]['score'];
                            }
                            
                            ?> 
                        </td>
                        <td> <?php echo ($row['check_status'] == 1 ) ? '<b>Checked</b>' : "<span style='color: red;'><b><i>Not Yet</i></b></span>";?> </td>
                        <td> <a href="javascript:loadPage('index.php?admin/checkresult&exam_id=<?php echo $row['exam_id']; ?>' + '&user_id=<?php echo $row['user_id']; ?>');"> Check Results</a></td>

                    </tr>
                    <?php
                }
            }
            ?>

        </table>
    </div>
</div>




<script language="javascript">
    $(document).ready(function(){
        $("#range_from").datepicker({dateFormat: 'yy-mm-dd'});
        $("#range_to").datepicker({dateFormat: 'yy-mm-dd'});
        $('#range_from').change(function(){
            //alert($(this).val());
            if ( $('#range_to').val().length > 1 ) {
                $.post('index.php?admin/examsresult',{ 'from' : $('#range_from').val(), 'to' : $('#range_to').val() },
                function( data ){
                    $('#result').html( data );
                })
            }
        });
        $('#range_to').change(function(){
            if ( $('#range_from').val().length > 1 ) {
                $.post('index.php?admin/examsresult',{ 'from' : $('#range_from').val(), 'to' : $('#range_to').val() },
                function( data ){
                    $('#result').html( data );
                })
            }
        });
    });
</script>
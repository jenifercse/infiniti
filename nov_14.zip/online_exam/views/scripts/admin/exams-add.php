
	<div id="exams" class="exams">
	<div class="exams_add_data">

	<form name="exams_add" id="exams_add" class="form-inline add-user"  >
		<fieldset><legend class="text-center">ADD EXAM</legend>
	
			<div class="row">
				<div class="col-md-4">
				 	<label for="exam_name"  class="form-group">Exam Name</label><br>
					<input type="text" id="exam_name" name="exam_name" class="user_input" >
				</div>
				<div class="col-md-4">
					<label for="From" class="form-group">From </label><br>
					<input id="exam_from" name="exam_from" class="user_input" type="text">
				</div>
				<div class="col-md-4">
					<label for="To" class="form-group">To</label><br>
					<input id="exam_to" name="exam_to" class="user_input" type="text">
				</div>

			</div><br>
			<div class="row">
				<div class="col-md-6">
				<label>Department Name </label><br>
					<select id="dept_id" name="dept_id">
						<option value=""> </option>
						<?php
						if (is_array($data['department'])){
							foreach($data['department'] as $row){
						?>
						<option value="<?php echo $row['department_id']; ?>"> <?php echo $row['department_name'];?> </option>
						<?php
								}
							}
						?>
					</select>
					</div>
					<div class="col-md-6"></div>
			</div><br>
			
			<div class="row">
				<div class="col-md-4">
					<label class="form-group">Total Points</label><br>
					<input type="text" id="total_points" name="total_points" class="user_input" onkeypress="return isNumberKey(event)" value="">
				</div>
				<div class="col-md-4">
					<label class="form-group">Passing Grade</label><br>
					<input type="text" id="passing_grade" name="passing_grade" class="user_input" onkeypress="return isNumberKey(event)" value="">
				</div>
				<div class="col-md-4"></div>
			</div><br>
			<div class="row">
				<div class="col-md-4">
					<label class="form-group">Time Limit</label><br>
					Hrs<br><input type='text' id='hrs' name='hrs' value="" onkeypress="return isNumberKey(event)">
				</div><br>
				<div class="col-md-4">
					Mins<br><input type='text' id='mins' name='mins' value="" onkeypress="return isNumberKey(event)">
				</div>
				<div class="col-md-4"></div>
			</div><br>
			
			<div class="row">
				<div class="col-md-5"></div>
				<div class="col-md-2">
					<input type="button" id="save" class="btn btn-info" value="Save">
					<a href="#" id="cancel" class="" value="Cancel">cancel</a>
				</div>
				<div class="col-md-5"></div>
			</div><br>
		
		</fieldset>
	</form>


</div>
</div>



<script language="javascript">

$(document).ready(function(){
	$("#exam_from").datepicker({dateFormat: 'yy-mm-dd'});
	$("#exam_to").datepicker({dateFormat: 'yy-mm-dd'});
	$('#cancel').click(function(){
		$('#exams').load('index.php?admin/exams');
	})
	$('#save').click(function(){
		var error ="Please fill up the requirement below \r\n----------------------------------------\r\n";
		var msg = error;
		if( $('#exam_name').val() == '' ){
			msg += '* Exam Name \r\n';
		}
		if( $('#exam_from').val() == '' ){
			msg += '* Date From \r\n';
		}
		if( $('#exam_to').val() == '' ){
			msg += '* Date To \r\n';
		}
		if( $('#dept_id').val() == '' ){
			msg += '* Department Name \r\n';
		}
		if( $('#passing_score').val() == '' ){
			msg += '* Passing score  \r\n';
		}
		if( $('#hrs').val() == '' ){
			msg += '* Hours  \r\n';
		}
		if( $('#mins').val() == '' ){
			msg += '* Mins  \r\n';
		}
		if (msg == error){
			$.post('index.php?admin/saveexamsnew',$("#exams_add").serialize(),function(data){
				$('#exams').load('index.php?admin/exams');
			});	
			
		}else{
			alert(msg);	
		}
	});
});
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
</script>
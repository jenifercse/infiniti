        <!-- NAVBAR STARTS HERE -->
        <div class="row bg2">
            <div class="navbar">
                <nav class="navbar navbar-default">
                    
                        <ul class="nav navbar-nav pull-right">
                          <li><i class="fa fa-user" aria-hidden="true"></i>ADMIN</li>
                          
                          <li><a href="index.php?authenticate/logout" class="logout"><i class="fa fa-sign-out " aria-hidden="true"></i>Logout</a></li>
                        </ul>
                     
                </nav>
            </div>
            <!-- NAVBAR ENDS HERE -->
        </div>
   






<div id="questions" class="questions" >
	<div>
		<input type="button"  value="Add New" id="add">
	</div>
	<div id="questions_list" class="questions_list">

	</div>
	<input type="hidden"  name="exam_id" id="exam_id" value="<?php echo $data;?>"/>
</div>




<script language="javascript">
$(document).ready(function(){

	$.get('index.php?admin/questionlist&exam_id='+$('#exam_id').val(),function(data){
		$('#questions_list').html(data);
	})

	$('#add').click(function(){
		$('#questions').load('index.php?admin/questionadd&exam_id='+$('#exam_id').val());
	});
});
</script>


<table>
  <tr>
  	<?php 
  		if ( $data[0]['exam_checker'] == 1 )
      {
      	?>
      	<td> &nbsp;<a href="javascript:loadPage('index.php?staff/examslist');"> Examinations Results </a>
        </td>
      	<?php
  		}
  	?>
  </tr>
</table>

<!DOCTYPE html>
<html>
<head>
    <title>online exam</title>
</head>
<link rel="stylesheet" type="text/css" href="public/css/basetemplate.css">
 <link rel="stylesheet" type="text/css" href="views/scripts/staff/css/nav.css">
<!-- <link rel="stylesheet" type="text/css" href="../css/style.css"> -->
<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
<!-- <link rel="javascript" type="script/javascript" href="../js/myscript.js"> -->
</head>
<body>
    <!-- MAIN CONTAINER STARTS HERE -->
    <div class="container-fluid">
        <!-- NAVBAR STARTS HERE -->
        <div class="row">
            <div class="navbar">
                <nav class="navbar navbar-light">
                     <div class="container-fluid">
                        <div class="navbar-header" >
                          <a class="navbar-brand" href="#"><img src="assets/images/infi3.jpeg" id="logo">
                          </a>
                        </div>
                        <ul class="nav navbar-nav pull-right">
                          <li class=""><a href="javascript:loadPage('index.php?staff/index');"> Examinations List </a></li>
                          <li><a href="index.php?authenticate/logout"> Logout </a></li>
                          
                        </ul>
                     </div>
                </nav>
            </div>
            <!-- NAVBAR ENDS HERE -->
        </div>








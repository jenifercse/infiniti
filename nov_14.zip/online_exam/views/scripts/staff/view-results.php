
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
</br>
<span>Exam name: <?php echo $data['exam_name'][0]['exam_name'];?></span>
<div>
<table>
<tr class="tr-head">
	<td><b> Questions  </b></td>
	<td><b> My Answers </b></td>
</tr>
<?php 
$cnt = 0;
$correct = 0;
if (is_array($data['transaction_dtl'])){
	foreach($data['transaction_dtl'] as $row){
	$cnt++;
		if ($row['israted'] <> 0){
			$correct += $row['score'];
		}
		
	
?>
<tr>
	<td class="line"> <?php  echo $cnt . '. ' . $row['question_name']; ?> <?php  echo ($row['israted'] == 0 ?  "<span style='color:gray;'> (Not yet graded) </span>" : '');?> </td>
	<?php
	if ($row['israted'] == 0){

	?>
		<td class="line"> <span style="color: black"><?php echo $row['essay']; ?> </span></td>
	<?php
	}else{
	?>
	<td class="line"> <span style="<?php echo ($row['score']==0 ? 'color: red' : 'color:green');?>"><?php echo ($row['answer_name'] != '' ? $row['answer_name'] : $row['essay']); ?> </span></td>
	<?php 
	}	
	?>
</tr>
<?php
	}
}
?>
</table>
<div style="float:right; padding-right: 10px; margin-right:35px;" class="mcstyle">
    <table class="mcstyle" style="font-size: 13px;">
    <tr>
        <td align="right"> <b> Score: </b></td>
        <td> <b> <?php echo $correct . ' out of ' . $data['exam_name'][0]['passing_score']; ?></b> </td>
    </tr>
    <tr>
        <td align="right"> <b>Grade: </b> </td>
         <td> 
         	<b>
     		<?php  $grade = ($correct/$data['exam_name'][0]['passing_score']) * 100 ;
     			echo $grade.'%';
        	 ?>  
        	</b> 
     	</td>
    </tr>
    <tr>
        <td align="right"> <b> Remark: </b></td>
        <td> 
        <?php
            if ( $grade >= $data['exam_name'][0]['passing_grade'] ) {
                echo "<span style='color: green;'><b>Passed</b></span>";
            }else{
                echo "<span style='color: red;'><b>Failed</b></span>";
            }
        ?>
        </td>
    </tr>
    </table>
	</br>
	<div style="float:right;">
		<input type="button" id="back" value="Back" action="exit();">
	</div>
</div>
</div>
</body>
</html>

<script language="javascript">
$(document).ready(function(){
	$('#back').click(function(){
		loadPage('index.php?staff/index');

	});
});
</script>
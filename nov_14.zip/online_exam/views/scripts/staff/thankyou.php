<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="views/scripts/staff/css/staff.css">
</head>
<body>
<div>
	<div>
		<b> Thank You For Taking The Exam </b>
	</br>
		<a href="index.php?staff/viewresults2&exam_id=<?php echo $_GET['exam_id'];?>"> View Results</a>
	</div>
</div>
</body>
</htm

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="views/scripts/staff/css/staff.css">
</head>
<body>
</br>
<span>Exam name: <?php echo $data['exam_name'][0]['exam_name'];?></span>
<form name="view" id="view" action="index.php?staff/index">
<div>

	<table>
	<tr>
		<td><b> Questions  </b></td>
		<td><b> My Answers </b></td>
	</tr>
	<?php 
	$cnt = 0;
	$correct = 0;
	if (is_array($data['transaction_dtl'])){
		foreach($data['transaction_dtl'] as $row){
		$cnt++;
			if ($row['israted'] <> 0){
				$correct += $row['score'];
			}
	?>
	<tr>
		<td> <?php  echo $cnt . '. ' . $row['question_name']; ?> <?php  echo ($row['israted'] == 0 ?  "<span style='color:gray;'> (Not yet graded) </span>" : '');?> </td>
		<?php
		if ($row['israted'] == 0){

		?>
			<td> <span><?php echo $row['essay']; ?> </span></td>
		<?php
		}else{
		?>
		<td> <span style="<?php echo ($row['score']==0 ? 'color: red' : 'color:green');?>"><?php echo ($row['answer_name'] != '' ? $row['answer_name'] : $row['essay']); ?> </span></td>
		<?php 
		}	
		?>
	</tr>
	<?php
		}
	}
	?>
	</table>
	<div>
    <table>
    <tr>
        <td> <b> Score: </b></td>
        <td> <b> <?php echo $correct . ' out of ' . $data['exam_name'][0]['passing_score']; ?></b> </td>
    </tr>
    <tr>
        <td> <b>Grade: </b> </td>
         <td> 
         	<b>
     		<?php  $grade = ($correct/$data['exam_name'][0]['passing_score']) * 100 ;
     			echo $grade.'%';
        	 ?>  
        	</b> 
     	</td>
    </tr>
    <tr>
        <td> <b> Remark: </b></td>
        <td> 
        <?php
            if ( $grade >= $data['exam_name'][0]['passing_grade'] ) {
                echo "<span style='color: green;'><b>Passed</b></span>";
            }else{
                echo "<span style='color: red;'><b>Failed</b></span>";
            }
        ?>
        </td>
    </tr>
    </table>
	</br>
	<div>
		<input type="button" id="back" value="Back">
	</div>
	</div>
</div>
</form>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script language="javascript">
$(document).ready(function(){
	$('#back').click(function(){
		//loadPage('index.php?staff/index');
		$('#view').action="index.php?staff/index";
		$('#view').submit();
	});
});
</script>
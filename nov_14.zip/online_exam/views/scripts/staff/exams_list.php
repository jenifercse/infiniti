
<div>

    <table border="0" cellspacing="0" cellpadding="5">
        <tr class="tr-head">
            <td width="270" class="line2"><b> Exam Name </b></td>
            <td width="120" class="line2"> <b>Exam Period </b></td>
            <td width="30" class="line2"> <b>Department </b></td>
            <td widt="150" class="">Action</td>
        </tr>
        <?php
        if (is_array($data)) {
            foreach ($data as $row) {
                // index.php?admin/examedit&exam_id=23
                //$link = "javascript:loadPage('index.php?admin/examedit&exam_id=".$row['exam_id']."')";
                $link = "javascript:loadPage('index.php?admin/questionlist&exam_id=" . $row['exam_id'] . "')";
                ?>
                <tr>
                    <td class="line"> <?php echo $row['exam_name']; ?> </td>
                    <td class="line"> <?php echo date('m-d-Y', strtotime($row['exam_from'])) . ' - ' . date('m-d-Y', strtotime($row['exam_to'])); ?> </td>
                    <td class="line"> <?php echo $row['department_name'];?></td>
                    <td width="100" align="center" class="line1">
                        <a href="javascript:loadPage('index.php?staff/examsresult&exam_id=<?php echo $row['exam_id'] ?>');"> View Result</a>
                    </td>
                </tr>
                <?php
            }
        }
        ?>
    </table>
</div>

</body>
</html>
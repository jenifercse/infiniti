


<div>
<table>
<tr class="tr-head">
	<td class="line2"><b> Exam Name </b></td>
	<td class="line2"><b> Period </b></td>
	<td width="100" class="line2"><b> Passing Grade </b></td>
	<td class="line2">Action</td>
</tr>
<?php 
if (is_array($data['exam'])){
	foreach($data['exam'] as $row){
?>
<tr>
	<td align="center" class="line">
		<?php echo $row['exam_name'];?>
	</td>
	<td class="line">
		<?php echo date('m-d-Y', strtotime($row['exam_from'])) . ' - ' . date('m-d-Y',strtotime($row['exam_to'])); ?>
	</td>
	<td class="line">
		<?php echo $row['passing_grade'] . '%';?>
	</td>
	<td width="100" align="center" class="line1">
		<?php 
		if (is_array($data[$row['exam_id']])){
		?>
			<!-- <a target="_blank" href="javascript:loadPage('index.php?staff/viewresults&exam_id=<?php // echo $row['exam_id'];?>');"> View Results </a> -->
			<a target="_blank" href="index.php?staff/viewresults&exam_id=<?php echo $row['exam_id'];?>"> View Results </a>
		<?php
		}else{
		?>
			<a target="_blank" href="index.php?staff/exam&exam_id=<?php echo $row['exam_id'];?>"> Take Exam </a>
		<?php	
		}
		?>
	</td>
</tr>
<?php
	}
}
?>
</table>
</div>
</body>
</html>

<table>
	<tr class="tr-head">
		<td>Examinees Name </td>
		<td>Exam Name </td>
		<td>Remarks </td>
		<td>View </td>
	</tr>

	<?php
		if(is_array($data['exam'])){
			foreach($data['exam'] as $row){
	?>
	<tr>
		<td align="center" class="line"> <?php echo $row['user_lname'] . ', ' . $row['user_fname'];?></td>
		<td align="center" class="line"> <?php echo $row['exam_name']; ?></td>
	<?php
	?>
		<td align="center" class="line"> 
			<?php 
				if ( (($data[$row['user_id']][0]['score'] / $row['passing_score']) * 100 ) >= $row['passing_grade'] ) {
					echo "<span style='color: green;'><b>Passed</b></span>";
				}else{
					echo "<span style='color: red;'><b>Failed</b></span>";
				}
			?> 
		</td>
		<td align="center" class="line1"> <a href="javascript:loadPage('index.php?admin/checkresult&exam_id=<?php echo $row['exam_id'];?>' + '&user_id=<?php echo $row['user_id'];?>');"> Check Results</a></td>

	</tr>
	<?php
			}
		}
	?>

</table>

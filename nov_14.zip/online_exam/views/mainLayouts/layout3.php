<html>
<head>
	<meta http-equiv="content-language" content="en"/>
	<meta http-equiv="content-style-type" content="text/css"/>
	<meta http-equiv="content-script-type" content="text/javascript"/>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<link rel="stylesheet" type="text/css" href="public/css/layout-z.css">
	<link rel="stylesheet" type="text/css" href="public/css/jquery.ui.datepicker.css">
	<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
    <script src="public/js/jquery.min.js"></script>
    <script src="public/js/jquery-ui.min.js"></script>
    <link href="public/css/jquery-ui.css" rel="stylesheet" type="text/css"/>
	<link href="https://fonts.googleapis.com/css?family=Bree+Serif|Roboto+Condensed&display=swap" rel="stylesheet">

	<link rel="stylesheet" type="text/css" href="public/css/basetemplate.css">
	<title> Online Exam </title>
</head>
<body>

<form action="index.php?authenticate/verify" method="post">
	<div class="container-fluid" class="theme-cyan font-montserrat light_version">
		<?php 
		//echo date('g:i A ',$data['data'][0]['lecture_time_from']);
		//echo 5400
		?>
		<div class="bodycontainer">
			<div class="left_menu">
				<?php 
					echo $data['nav'];
				?>
			</div>
		
		</div>
	</div>	
</form>
</body>
</html>

<script language="javascript">
	function loadPage( url ){
		//alert(url);
		$('.body_data').load( url );
	}
	function deleteData( url, loadBack ){
		if (confirm("Do you want to delete this??")){
			$.post(url,function(){
				$('.body_data').load( loadBack );
			})	;
		}
	}
	$(document).ready(function(){
		//$("#exam_from2").datepicker();
		loadPage('index.php?staff/index');
	});		
	</script>
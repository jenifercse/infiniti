
<?php
include 'template.php';
?>
<aside class="app-sidebar">
    <div id="left-sidebar" class="sidebar" id="wrapper">
        <div class="navbar-brand">
            <a href="index.html"><img src="../assets/images/icon.svg" alt="Oculux Logo" class="img-fluid logo"><span>Online Exam</span></a>
            <button type="button" class="btn-toggle-offcanvas btn btn-sm float-right"><i class="lnr lnr-menu icon-close"></i></button>
        </div>
        <div class="sidebar-scroll">
            <!-- <div class="user-account">
                <div class="user_div">
                    <img src="../assets/images/user.png" class="user-photo" alt="User Profile Picture">
                </div>
                <div class="dropdown">
                    <span>Welcome,</span>
                    <a href="javascript:void(0);" class="dropdown-toggle user-name" data-toggle="dropdown"><strong>ADMIN</strong></a>
                    <ul class="dropdown-menu dropdown-menu-right account vivify flipInY">
                        <li><a href="profile.html"><i class="icon-user"></i>My Profile</a></li>
                        <li><a href="app-inbox.html"><i class="icon-envelope-open"></i>Messages</a></li>
                        <li><a href="javascript:void(0);"><i class="icon-settings"></i>Settings</a></li>
                        <li class="divider"></li>
                        <li><a href="page-login.html"><i class="icon-power"></i>Logout</a></li>
                    </ul>
                </div>                
            </div>   -->
            <nav id="left-sidebar-nav" class="sidebar-nav">
                <ul id="main-menu" class="metismenu">
                    <li class="header">Main</li>
                    <li class="active open"><a href="index.html"><i class="icon-speedometer"></i><span>ADMIN </span></a></li>
                    <li><a href="users.php"><i class="icon-user"></i><span>USERS</span></a></li>
                    <li><a href="departments.html"><i class="icon-grid"></i><span>DEPARTMENTS</span></a></li>
                    <li><a href="employee.html"><i class="icon-users"></i><span>EXAMINATIONS</span></a></li>
                    <li><a href="activities.html"><i class="icon-equalizer"></i><span>RESULTS</span></a></li>
                </ul>
            </nav>     
        </div>
    </div>
    </aside>
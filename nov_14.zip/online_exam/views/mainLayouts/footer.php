</body>
</html>
<!-- Javascript -->
<script src="../html/assets/bundles/libscripts.bundle.js"></script>
<script src="../html/assets/bundles/vendorscripts.bundle.js"></script>

<script src="../html/assets/bundles/c3.bundle.js"></script>
<script src="../html/assets/bundles/flotscripts.bundle.js"></script>
<script src="../html/assets/bundles/jvectormap.bundle.js"></script>
<script src="../assets/vendor/jvectormap/jquery-jvectormap-us-aea-en.js"></script>

<script src="../html/assets/bundles/mainscripts.bundle.js"></script>
<script src="../html/assets/js/hrdashboard.js"></script>


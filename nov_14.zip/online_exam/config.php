	<?php
#configure the shortcut name

DEFINE ('BASE_URL', 'index.php?'); #change this if needed
// realpath() function returns the path of a given file.it is again given to the dirname() function it returns the perent directory of the file.it is defined as the home directory.
DEFINE ('HOME_DIR', dirname( realpath(__FILE__)) );
// home directory given as a parameter ,Return filename from the specified path.
DEFINE ('BASE_DIR', basename(HOME_DIR));//online_exam is the base directory
DEFINE ('LIB_DIR', HOME_DIR . '/libraries');
DEFINE ('CLASS_DIR', LIB_DIR . '/classes/');
DEFINE ('MODEL_DIR', HOME_DIR . '/models/');
DEFINE ('VIEW_DIR', HOME_DIR . '/views/');
DEFINE ('CONTROLLER_DIR', HOME_DIR . '/controllers/');
DEFINE ('DATABASE_DIR', LIB_DIR . '/database/');
DEFINE ('CONT_EXT','Controller.php');
DEFINE ('CORE_DIR',LIB_DIR . '/core/');
DEFINE ('EXT', '.php');

#DATABASE CONFIGURATION
DEFINE ('DB_HOST','localhost');
DEFINE ('DB_USER','root');
DEFINE ('DB_PASS','');
DEFINE ('DB_NAME','online_exam');
// DEFINE ('DB_PORT','3306');

#DATABASE PREFIX

//DEFINE ('cool_forum', 'cool_school_');

#DEFAULT CONTROLLER / ACTION
DEFINE ('default_controller','index'); 
DEFINE ('default_action','mainAction');	

#load libraries needed
require_once (CLASS_DIR . 'Session' . EXT);

require_once (CORE_DIR . 'Common' . EXT);

require_once (DATABASE_DIR . 'Db' . EXT);

require_once (CORE_DIR . 'Controller' . EXT);

require_once (CORE_DIR . 'Router' . EXT);


?>
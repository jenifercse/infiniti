<?php
include 'template.php';
?>
<header class="app-header" id="wrapper">
        <nav class="navbar top-navbar">
            <div class="container-fluid">

                <div class="navbar-left">
                    <div class="navbar-btn">
                        <a href="index.html"><img src="../assets/images/infi3.jpeg"  class="img-fluid logo"></a>
                        <button type="button" class="btn-toggle-offcanvas"><i class="lnr lnr-menu fa fa-bars"></i></button>
                    </div>
                    
                </div>
                
                <div class="navbar-right">
                    <div id="navbar-menu">
                        <ul class="nav navbar-nav">
                            <li><a href="index.php?authenticate/logout" class="icon-menu"><i class="icon-power">
                            </i></a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="progress-container"><div class="progress-bar" id="myBar"></div></div>
        </nav>
    </header>
   
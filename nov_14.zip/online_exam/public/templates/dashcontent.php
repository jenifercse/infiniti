
<?php
include 'template.php';
?>
<div id="main-content" id="wrapper">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row clearfix">
                    <div class="col-md-6 col-sm-12">
                        <h1>Dashboard</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">INFINITI</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                            </ol>
                        </nav>
                    </div>            
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="card">
                        <div class="body ribbon">
                            <div class="ribbon-box green">5</div>
                            <a href="users.html" class="my_sort_cut text-muted">
                                <i class="icon-users"></i>
                                <span>Users</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="card">
                        <div class="body">
                            <a href="holidays.html" class="my_sort_cut text-muted">
                                <i class="icon-like"></i>
                                <span>Departments</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="card">
                        <div class="body ribbon">
                            <div class="ribbon-box orange">8</div>
                            <a href="events.html" class="my_sort_cut text-muted">
                                <i class="icon-calendar"></i>
                                <span>Examinations</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="card">
                        <div class="body">
                            <a href="payroll.html" class="my_sort_cut text-muted">
                                <i class="icon-credit-card"></i>
                                <span>Examinations result</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            
        </div>
    </div>
<?php
/******************************************************************
	ABOUT THE AUTHOR
	CREATED BY: 
*******************************************************************/

Class _Db{
	private $user;
	private $pass;
	private $host;
	private $dbname;
	private $connection;
	private $mysqli_result;
	
	public function __construct()
	{
		$this->user = DB_USER;
		$this->pass = DB_PASS;
		$this->host = DB_HOST;
		$this->dbname = DB_NAME;
		
	}

	public function connect(){

		$this->connection = mysqli_connect( $this->host, $this->user, $this->pass) or die('error connection');
		mysqli_select_db($this->connection,  $this->dbname );
		
	}
	public function query(  $str , $assoc_type = 'mysqli_assoc' )
	{
		$this->connect();

		if( strpos(strtolower($str), 'select') === 0 ){
		
		$this->mysqli_result = mysqli_query( $this->connection, $str );
			if ( $this->mysqli_result && mysqli_error($this->connection) == '' ){
					switch ( $assoc_type )
					{
						case 'mysqli_assoc':
							while( $row= mysqli_fetch_assoc( $this->mysqli_result ) ) {
								$result[] =  $row;

							}
							// print_r($result);
							// exit();
							// return $result;
						break;
						
						case 'fetch_row':
							return $result = mysqli_fetch_row( $this->mysqli_result );
						break;
					}
			}else{
				return mysqli_error($this->connection);
			}
		}else{
			mysqli_query( $this->connection, $str );
		}
		if ( isset($result) ) return $result;
		
	}
	
	public function insert( $table, $values ) {
		$fields = implode(",", array_keys($values) );
		$val = implode("," , array_values($values) );
		//echo "INSERT INTO ".$table. "(".$fields.") VALUES (".$val .")";
		return $this->query("INSERT INTO ".$table. "(".$fields.") VALUES (".$val .")");
	}
	/*
	public function update( $table, $values, $where = null ){
		for($fields = 0; $fields < count(array_keys($values)); $fields ++){
			$fields_val = isset( $fields_val ) ? $fields_val  . array_keys($values)[$fields] . '=' :   array_keys($values)[$fields] . '=';
			for($val = $fields; $val <= $fields; $val++){
				//$fields_val .= ( $val== count(array_keys($values)) - 1  ) ? array_values($values)[$val] : array_values($values)[$val] . ',';
			}
		}
		$this->query("UPDATE {$table} SET $fields_val {$where}");
	}
	*/
	public function delete( $table, $where = null ){
		return $this->query("DELETE FROM {$table} {$where}");
	}

	public function fetch_all_rows( $sql, $assoc_type = 'mysqli_assoc' ){
		return $this->query($sql, $assoc_type);
	}
}
?>
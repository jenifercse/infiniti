<?php
/******************************************************************
	ABOUT THE AUTHOR
	WRITTEN and DEVELOPED by : 
*******************************************************************/

Class _Controller {
	public function __construct(){
		$this->load = load_class('Loader',CORE_DIR);
		$this->set  = load_class('Set', CORE_DIR);
	}
}
?>